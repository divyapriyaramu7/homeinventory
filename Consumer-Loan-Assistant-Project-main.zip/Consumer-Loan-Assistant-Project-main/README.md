# Consumer-Loan-Assistant-Project
# Problem statement : (Ever wonder just) How much those credit card accounts are costing you ?

# Abstract : This project will help you get a handle on consumer debt. The Consumer Loan Assistant Project you would build computes payments and loan terms given balance and interest information. We look at focus traversal among controls, how to do input validation, and the message box for user feedback.

# This project has a detailed Code Specifications along with the code blocks. It is expected that the Intern follows each step carefully and implements the project. At the end of project docs certain enhancements are given, which are optional, but recommended to be done.
